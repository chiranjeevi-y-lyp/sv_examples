class seq_item;
  rand bit [7:0] val;
  rand bit en;
  
  constraint en_c { solve en before val;
                    if(en == 1) { val inside {[0:100]}; }
                  }
endclass

module constraint_example;
  seq_item item;
  
  initial begin
    item = new();
    
    repeat(5) begin
      item.randomize();
      $display("en = %0d, val = %0d", item.en, item.val);
    end
  end
endmodule
