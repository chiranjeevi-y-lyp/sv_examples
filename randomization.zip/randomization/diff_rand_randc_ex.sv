class generator;

  // Normal random variable
  rand  bit [1:0] rand_val;

  // Random cyclic variable
  randc bit [1:0] randc_val;

endclass


module test;

  generator g;

  initial begin

    g = new();

    repeat(10) begin

      g.randomize();

      $display("rand = %0d    randc = %0d",
                g.rand_val, g.randc_val);

    end

  end

endmodule
