class packet;

  rand bit [7:0] addr;
  rand bit [7:0] data;

endclass

module test;

  packet p;

  initial begin
    p = new();

    repeat(5) begin
      p.randomize();
      $display("addr = %0d, data = %0d", p.addr, p.data);
    end
  end

endmodule
