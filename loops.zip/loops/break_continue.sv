module break_continue_tb;
  int data;

  initial begin
    repeat (15) begin
      data = $urandom_range(1, 50);

      // Skip small values
      if (data < 10)
        continue;

      $display("Valid data: %0d", data);

      // Stop if large value found
      if (data > 40) begin
        $display("High value detected → stopping");
        break;
      end
    end
  end
endmodule
