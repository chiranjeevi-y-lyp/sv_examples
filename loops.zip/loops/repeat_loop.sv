module repeat_loop_ex;

  int data;
  int pkt_count = 0;

  initial begin
    $display("Starting stimulus generation...");

    // Generate 10 transactions
    repeat (10) begin
      data = $urandom_range(0, 255);  // random stimulus
      pkt_count++;

      $display("Packet %0d : Data = %0d", pkt_count, data);

      #10; // delay (simulate time between transactions)
    end

    $display("Finished generating %0d packets", pkt_count);
  end

endmodule

