module while_example;
  int num;

  initial begin
    num = $urandom_range(1, 50);

    // Keep generating until we get an even number
    while (num % 2 != 0) begin
      $display("Generated odd number: %0d", num);
      num = $urandom_range(1, 50);
    end

    $display("Final even number: %0d", num);
  end
endmodule
