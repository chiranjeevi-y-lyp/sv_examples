module parity_tb;

  function bit calc_parity(input bit [7:0] data);
    return ^data;  // XOR reduction
  endfunction

  initial begin
    bit [7:0] data = 8'b10110101;
    bit parity;

    parity = calc_parity(data);

    $display("Data = %b, Parity = %b", data, parity);
  end

endmodule
