module task_tb;

  logic clk;
  logic data;

  // Clock generation
  always #5 clk = ~clk;

  task send_bit(input logic d);
    @(posedge clk);
    data = d;
    $display("Sent bit = %0b at time %0t", d, $time);
  endtask

  initial begin
    clk = 0;

    send_bit(1);
    send_bit(0);
    send_bit(1);
  end

endmodule
