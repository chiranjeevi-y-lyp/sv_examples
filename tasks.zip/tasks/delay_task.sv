module task_delay;

  task wait_and_print();
    #5;
    $display("Printed after 5 time units at time %0t", $time);
  endtask

  initial begin
    $display("Start time = %0t", $time);
    wait_and_print();
  end

endmodule
