module driver_example;

  logic clk;
  logic valid;
  logic [7:0] data;

  always #5 clk = ~clk;

  // Task to send one transaction
  task automatic send_transaction(input [7:0] d);
    @(posedge clk);
    valid <= 1;
    data  <= d;

    @(posedge clk);
    valid <= 0;

    $display("Transaction sent: %0h at time %0t", d, $time);
  endtask

  initial begin
    clk = 0;

    send_transaction(8'hA5);
    send_transaction(8'h3C);
    send_transaction(8'hFF);
  end

endmodule
