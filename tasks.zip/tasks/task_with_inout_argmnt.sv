module task_inout;

  task increment(inout int value);
    value = value + 1;
  endtask

  int num = 10;

  initial begin
    increment(num);
    $display("Updated num = %0d", num);
  end

endmodule
