module task_output;

  task add(input int a, input int b, output int result);
    result = a + b;
  endtask

  int sum;

  initial begin
    add(5, 7, sum);
    $display("Sum = %0d", sum);
  end

endmodule
