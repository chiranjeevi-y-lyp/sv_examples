module task_automatic;

  task automatic multiply(input int a, input int b, output int result);
    result = a * b;
  endtask

  initial begin
    int res1, res2;
    fork
      multiply(2, 3, res1);
      multiply(4, 5, res2);
    join

    $display("res1 = %0d, res2 = %0d", res1, res2);
  end

endmodule
