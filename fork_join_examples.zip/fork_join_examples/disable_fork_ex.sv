module disable_fork_example;

  logic done;

  // Task: Simulated operation
  task automatic operation();
    #30;
    done = 1;
    $display("Operation completed at %0t", $time);
  endtask

  // Task: Timeout watcher
  task automatic timeout();
    #20;
    $display("Timeout triggered at %0t", $time);
  endtask

  initial begin
    done = 0;

    fork
      operation();  // takes longer
      timeout();    // finishes first
    join_any

    // Kill the remaining process
    disable fork;

    if (done)
      $display("SUCCESS: Operation finished");
    else
      $display("FAIL: Operation timed out");

    $finish;
  end

endmodule
