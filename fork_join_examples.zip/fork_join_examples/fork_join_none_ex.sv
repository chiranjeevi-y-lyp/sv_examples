module fork_join_none_real;

  logic clk;
  logic [7:0] data;

  always #5 clk = ~clk;

  task monitor();
    forever begin
      @(posedge clk);
      $display("Monitoring data = %0h at %0t", data, $time);
    end
  endtask

  initial begin
    clk = 0;

    fork
      monitor();  // runs forever in background
    join_none

    // Main stimulus continues
    repeat(5) begin
      @(posedge clk);
      data = $random;
      $display("Generated data: %0h", data);
    end

    $display("Main process completed");
    #10;
    $finish;
  end

endmodule
