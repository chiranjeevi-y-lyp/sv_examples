module fork_join_any_real;

  logic done;

  task operation();
    #30;
    done = 1;
    $display("Operation completed at %0t", $time);
  endtask

  task timeout();
    #20;
    $display("Timeout occurred at %0t", $time);
  endtask

  initial begin
    done = 0;

    fork
      operation(); // long task
      timeout();   // timeout checker
    join_any

    if (!done)
      $display("Operation did NOT finish (timeout case)");
    else
      $display("Operation finished before timeout");

  end

endmodule
