module fork_join_real;

  logic clk;
  logic [7:0] data;

  always #5 clk = ~clk;

  task send_data();
    repeat(3) begin
      @(posedge clk);
      data = $random;
      $display("Sent data: %0h at %0t", data, $time);
    end
  endtask

  task check_data();
    repeat(3) begin
      @(posedge clk);
      $display("Checking data at %0t", $time);
    end
  endtask

  initial begin
    clk = 0;

    fork
      send_data();   // process 1
      check_data();  // process 2
    join   // waits for BOTH to finish

    $display("All operations completed at %0t", $time);
  end

endmodule
