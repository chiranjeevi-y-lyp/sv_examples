module associative_array_ex;
  int arr[string];  // key = string

  initial begin
    arr["apple"] = 10;
    arr["banana"] = 20;

    foreach(arr[key])
      $display("%s = %0d", key, arr[key]);
  end
endmodule
