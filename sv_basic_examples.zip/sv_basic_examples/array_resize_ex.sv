module array_resize_ex;
  bit[31:0] d_arr[];
  
  initial begin
    d_arr = new[5];
    d_arr = '{1,2,3,4,5};
    
    foreach(d_arr[i]) begin
      $display("before resize d_arr[%0d]=%0d", i, d_arr[i]);
    end

    d_arr = new[10](d_arr);

    foreach(d_arr[i]) begin
      $display("after resize d_arr[%0d]=%0d", i, d_arr[i]);
    end
  end
endmodule
