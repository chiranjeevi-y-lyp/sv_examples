module foreach_example;
  int array[5];

  initial begin
    array = '{100,200,300,400,500};
    foreach (array[i]) begin
      $display("array[%0d] = %0d", i, array[i]);
    end
  end
endmodule
