module all_datatypes_example;

  // ----------------------------
  // 1. 2-State Data Types
  // ----------------------------
  bit        b_var;        // 1-bit (0 or 1)
  int        i_var;        // 32-bit signed
  byte       by_var;       // 8-bit signed
  shortint   s_var;        // 16-bit
  longint    l_var;        // 64-bit

  // ----------------------------
  // 2. 4-State Data Types
  // ----------------------------
  logic      l_bit;        // can be 0,1,X,Z
  reg        r_var;        // legacy type
  wire       w_var;        // net type

  // ----------------------------
  // 3. Packed Array
  // ----------------------------
  logic [7:0] packed_arr;  // 8-bit vector

  // ----------------------------
  // 4. Unpacked Array
  // ----------------------------
  int unpacked_arr[5];     // array of 5 integers

  // ----------------------------
  // 5. Dynamic Array
  // ----------------------------
  int dyn_arr[];

  // ----------------------------
  // 6. Associative Array
  // ----------------------------
  int assoc_arr[string];   // key = string

  // ----------------------------
  // 7. Queue
  // ----------------------------
  int q[$];                // queue

  // ----------------------------
  // 8. Enum
  // ----------------------------
  typedef enum {IDLE, BUSY, DONE} state_t;
  state_t state;

  // ----------------------------
  // 9. Struct
  // ----------------------------
  typedef struct {
    int id;
    string name;
  } person_t;

  person_t p1;

  // ----------------------------
  // 10. Union
  // ----------------------------
  typedef union {
    int i;
    byte b;
  } data_u;

  data_u u1;

  // ----------------------------
  // 11. String
  // ----------------------------
  string str;

  // ----------------------------
  // 12. Event
  // ----------------------------
  event ev;

  // ----------------------------
  // 13. Class (OOP Data Type)
  // ----------------------------
  class my_class;
    int data;
  endclass

  my_class obj;

  // ----------------------------
  // 14. Initialization & Usage
  // ----------------------------
  initial begin
    // 2-state
    b_var = 1;
    i_var = 10;

    // 4-state
    l_bit = 'x;

    // Packed
    packed_arr = 8'hA5;

    // Unpacked
    unpacked_arr = '{1,2,3,4,5};

    // Dynamic array
    dyn_arr = new[3];
    dyn_arr = '{10,20,30};

    // Associative array
    assoc_arr["one"] = 1;
    assoc_arr["two"] = 2;

    // Queue
    q.push_back(5);
    q.push_front(2);

    // Enum
    state = IDLE;

    // Struct
    p1.id = 1;
    p1.name = "SV";

    // Union
    u1.i = 32'hFF;

    // String
    str = "Hello SystemVerilog";

    // Event trigger
    -> ev;

    // Class
    obj = new();
    obj.data = 100;

    // Display
    $display("int = %0d, string = %s, queue size = %0d", i_var, str, q.size());
  end

endmodule
