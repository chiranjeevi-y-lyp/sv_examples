module pattern_101(
 input logic clk,
 input logic rst,
 input logic din,
 output logic dout
);

 typedef enum logic[1:0] {SR, S1, S10} state;
 state current_st, next_st;

 // State register
 always_ff @(posedge clk or posedge rst) begin
   if (rst)
     current_st <= SR;
   else
     current_st <= next_st;
 end

 // Next state logic + output logic
 always_comb begin
   case (current_st)
     SR: begin
       if (din) begin
         next_st = S1;
         dout = 0;
       end else begin
         next_st = SR;
         dout = 0;
       end
     end

     S1: begin
       if (!din) begin
         next_st = S10;
         dout = 0;
       end else begin
         next_st = S1;
         dout = 0;
       end
     end

     S10: begin
       if (din) begin
         next_st = S1;
         dout = 1; // detected 101
       end else begin
         next_st = SR;
         dout = 0;
       end
     end
   endcase
 end

endmodule
