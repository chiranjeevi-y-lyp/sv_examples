module dynamic_array_ex;
  int arr[];

  initial begin
    arr = new[5];  // allocate memory

    foreach(arr[i])
      arr[i] = i * 2;

    foreach(arr[i])
      $display("arr[%0d] = %0d", i, arr[i]);
  end
endmodule
