module static_array_ex;
  int arr[5];  // fixed size = 5

  initial begin
    arr[0] = 10;
    arr[1] = 20;

    foreach(arr[i])
      $display("arr[%0d] = %0d", i, arr[i]);
  end
endmodule
