module packed_best;

  bit [7:0] data;  // packed array (8 bits)

  initial begin
    data = 8'b11010110;

    $display("Full data = %b", data);

    // Bit access
    $display("MSB = %b", data[7]);
    $display("LSB = %b", data[0]);

    // Slicing
    $display("Upper 4 bits = %b", data[7:4]);
    $display("Lower 4 bits = %b", data[3:0]);
  end

endmodule
