module unpacked_best;

  int arr[5];  // unpacked array (5 elements)

  initial begin
    // Assign values
    foreach(arr[i]) begin
      arr[i] = i * 10;
    end

    // Display values
    foreach(arr[i]) begin
      $display("arr[%0d] = %0d", i, arr[i]);
    end
  end

endmodule
