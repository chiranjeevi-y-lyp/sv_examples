module d_arr_ex;
  bit [7:0] d_arr[];
  int index;

  initial begin
    index = 7; // delete 8th element

    d_arr = new[10];

    // Fill random data
    foreach (d_arr[i]) begin
      d_arr[i] = $urandom_range(0,255);
    end

    // Before delete
    foreach (d_arr[i]) begin
      $display("before d_arr[%0d]=%0d", i, d_arr[i]);
    end 

    // Shift elements left
    for (int i = index; i < d_arr.size()-1; i++) begin
      d_arr[i] = d_arr[i+1];
    end

    // Resize array
    d_arr = new[d_arr.size()-1](d_arr);

    // After delete
    foreach (d_arr[i]) begin
      $display("after d_arr[%0d]=%0d", i, d_arr[i]);
    end 
  end

endmodule
