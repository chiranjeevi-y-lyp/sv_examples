module multi_array_ex;
  int arr[2][3];

  initial begin
    foreach(arr[i,j])
      arr[i][j] = i + j;

    foreach(arr[i,j])
      $display("arr[%0d][%0d] = %0d", i, j, arr[i][j]);
  end
endmodule
